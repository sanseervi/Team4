package com.example.userapp;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.client.RestTemplate;


@SpringBootApplication

@RestController

//Load balancing at the client side
@RibbonClient(name="RibbonDemo" , configuration=RibbonConfiguration.class)

public class UserAppApplication {
	
	
	@Autowired
	
	private RestTemplate template;

	
	@GetMapping("/invoke")
	
	public String invokeHello() {
		
	String test = template.getForObject("http://RibbonDemo/hello",String.class);
		
	return test;
	
}
	
	
	
public static void main(String[] args) {
		
	SpringApplication.run(UserAppApplication.class, args);
	
}
	
	
	@Bean
	
	@LoadBalanced
	
	public RestTemplate temp() {

	//This method will execute for load balance		
	return new RestTemplate();
	
	}


}
